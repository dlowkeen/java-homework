package stack;

public class StackUnderflowException extends Throwable {
	public StackUnderflowException(String the_stack_is_full) {

    }
}
