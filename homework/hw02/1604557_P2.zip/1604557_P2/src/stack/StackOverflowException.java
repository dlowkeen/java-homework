package stack;

public class StackOverflowException extends Throwable {
    public StackOverflowException(String the_stack_is_full) {

    }
}
